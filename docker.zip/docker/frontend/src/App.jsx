import { useState, useEffect } from 'react'

function App() {
    const [backendStatus, setBackendStatus] = useState('Checking...')
    const [dbStatus, setDbStatus] = useState('Checking...')

    const checkStatus = () => {
        setBackendStatus('Checking...')
        setDbStatus('Checking...')

        fetch('/api/health')
            .then(res => res.json())
            .then(data => setBackendStatus(data.status))
            .catch(() => setBackendStatus('Backend unreachable'))

        fetch('/api/db-check')
            .then(res => res.json())
            .then(data => setDbStatus(data.status))
            .catch(() => setDbStatus('DB unreachable (check API)'))
    }

    useEffect(() => {
        checkStatus()
    }, [])

    return (
        <div className="container">
            <h1>Dockerized Multi-Service App</h1>
            <div className="card">
                <p>Backend Status: <strong>{backendStatus}</strong></p>
                <p>Database Status: <strong>{dbStatus}</strong></p>
                <button onClick={checkStatus} style={{ marginTop: '20px', padding: '10px 20px', cursor: 'pointer' }}>
                    Refresh Status
                </button>
            </div>
            <p className="read-the-docs">
                Built for the client to demonstrate Docker / Docker Compose orchestration.
            </p>
        </div>
    )
}

export default App
